macro("testpackagemacro", lambda ctx: "hello!")
macro("testpackagemacro2", lambda ctx: "hello!")


